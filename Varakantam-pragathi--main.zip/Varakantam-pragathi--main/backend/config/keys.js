const MONGO_URI = "mongodb+srv://rdavidlivingstone:david21@namastenode.1didy.mongodb.net/meal-box";

const JWT_SECRET = "Think";



module.exports = {MONGO_URI, JWT_SECRET};